# `huffman`

[![Travis CI][travis-badge]][travis-link]
[![Codecov.io][codecov-badge]][codecov-link]
[![PyPI][pypi-badge]][pypi-link]

Generate Huffman codebooks! [See the rST readme](README.rst) for use, this README is more for dev info/badge bling.

[codecov-badge]: https://img.shields.io/codecov/c/github/nicktimko/huffman.svg?maxAge=2592000?style=flat-square
[pypi-badge]: https://img.shields.io/pypi/v/huffman.svg?maxAge=2592000?style=flat-square  
[travis-badge]: https://img.shields.io/travis/nicktimko/huffman.svg?maxAge=2592000?style=flat-square

[codecov-link]: https://codecov.io/gh/nicktimko/huffman
[pypi-link]: https://pypi.python.org/pypi/huffman
[travis-link]: https://travis-ci.org/nicktimko/huffman
